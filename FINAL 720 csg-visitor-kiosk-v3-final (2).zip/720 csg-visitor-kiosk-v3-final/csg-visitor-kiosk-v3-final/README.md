# CSG Visitor Kiosk (existing Postgres server)

Visitor check-in kiosk with Slack notifications and an admin dashboard.
One app container; all data (visits, admin accounts, check-in name list)
lives on YOUR existing Postgres server in tables prefixed `kiosk_`, so it
coexists politely with anything else on that database. Nothing sensitive
is in the page source: sign-in is verified by the server and passwords
are stored hashed.

## Deploy

1. Copy this whole folder onto the host machine.
2. Create the connection file:
   ```
   copy .env.example .env     (Windows)
   cp .env.example .env       (Linux/Mac)
   ```
   Edit `.env` and fill in your Postgres connection details (either the
   single DATABASE_URL line or the separate PG* lines). If your server
   requires SSL, uncomment PGSSL=require.
3. Start it:
   ```
   docker compose up -d --build
   ```
   On first startup the app creates its three `kiosk_` tables and seeds
   the admin accounts and the name list. The Postgres user in .env needs
   permission to create tables in that database.
4. Test: `http://<host>:3000/api/health` should show `{"ok":true,"db":true}`.
   If db is false, the connection details are wrong; `docker compose logs app`
   shows the exact error.

## Admin dashboard

- `http://<host>:3000#admin`
- Visitor History tab: filter by time period, chart, full history,
  Export to Excel (exports exactly the selected period)
- Settings tab: add/remove names from the kiosk dropdown (with optional
  Slack member ID for personal @mentions) and change your own password
- IMPORTANT: all three seeded accounts start with the same placeholder
  password. Each admin should sign in and change theirs on day one.

## Forgotten password

```
docker compose exec app node reset-password.js someone@thisiscsg.com NewPassword123
```

## Day-to-day

- Kiosk URL: `http://<host>:3000` (point the MDM browser here)
- Logs: `docker compose logs app`
- Restart: `docker compose restart` (admins just sign in again afterward)
- Update code: edit, then `docker compose up -d --build`

## Backups and data safety

All data lives on the Postgres server, so it is covered by whatever backup
routine that server already has (worth confirming with whoever runs it).
Docker commands on this app can NOT delete your data; even
`docker compose down -v` only removes the app, never the database.
The only way to lose data is deleting the `kiosk_` tables on the
Postgres server itself.
