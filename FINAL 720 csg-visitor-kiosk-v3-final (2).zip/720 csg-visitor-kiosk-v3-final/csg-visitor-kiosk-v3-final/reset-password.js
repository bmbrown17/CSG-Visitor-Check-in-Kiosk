/* Forgot-password rescue. Run on the server:
   docker compose exec app node reset-password.js someone@thisiscsg.com NewPassword123 */
const crypto = require("crypto");
const { Pool } = require("pg");

const email = process.argv[2];
const newPass = process.argv[3];
if (!email || !newPass) {
  console.log("Usage: node reset-password.js <email> <new-password>");
  process.exit(1);
}
const poolConfig = {};
if (process.env.DATABASE_URL) poolConfig.connectionString = process.env.DATABASE_URL;
if (process.env.PGSSL === "require") poolConfig.ssl = { rejectUnauthorized: false };
const pool = new Pool(poolConfig);

const salt = crypto.randomBytes(16).toString("hex");
const hash = crypto.scryptSync(newPass, salt, 64).toString("hex");
pool
  .query("UPDATE kiosk_admins SET pass_hash = $1, salt = $2 WHERE email = $3", [hash, salt, email.toLowerCase()])
  .then((r) => {
    console.log(r.rowCount ? "Password updated for " + email : "No admin found with that email");
    process.exit(0);
  })
  .catch((e) => {
    console.error(e.message);
    process.exit(1);
  });
