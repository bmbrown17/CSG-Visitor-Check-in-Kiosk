/* CSG Visitor Kiosk server (external Postgres version)
   Serves the kiosk page; stores visits, admin accounts, and the employee
   directory on your existing Postgres server. Connection details come from
   the .env file (see .env.example). Tables are prefixed kiosk_ so this app
   stays out of the way of anything else on the same database. */

const express = require("express");
const path = require("path");
const crypto = require("crypto");
const { Pool } = require("pg");

const app = express();
app.use(express.json());

const poolConfig = {};
if (process.env.DATABASE_URL) poolConfig.connectionString = process.env.DATABASE_URL;
if (process.env.PGSSL === "require") poolConfig.ssl = { rejectUnauthorized: false };
const pool = new Pool(poolConfig); // also reads PGHOST/PGPORT/PGUSER/PGPASSWORD/PGDATABASE

/* ---------- password hashing ---------- */
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}
function verifyPassword(password, salt, expectedHash) {
  const actual = Buffer.from(hashPassword(password, salt), "hex");
  const expected = Buffer.from(expectedHash, "hex");
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

/* ---------- first-boot seeding ----------
   These only run when the tables are EMPTY (the very first startup).
   After that, all changes happen from the admin dashboard. */
const SEED_ADMINS = [
  { email: "p.hart@thisiscsg.com",      name: "Admin Peyton", password: "abcd1234" },
  { email: "jjablonski@thisiscsg.com",  name: "Admin John",   password: "abcd1234" },
  { email: "lcopertino@thisiscsg.com",  name: "Admin Lianne", password: "abcd1234" },
];
const SEED_EMPLOYEES = [
  { name: "Austin Bucker",     slackId: "UFHESDCQ5" },
  { name: "Brandan Armstrong", slackId: "U0532SNC5PX" },
  { name: "Caitlyn Sharpe",    slackId: "U0140V4CSF9" },
  { name: "John Jablonski",    slackId: "U01ETLSLWDP" },
  { name: "Lianne Copertino",  slackId: "U031AJ802HX" },
  { name: "Lori Fazio",        slackId: "UEQDUJ2M6" },
  { name: "Luci Pittman",      slackId: "U8EP1HYTD" },
  { name: "Peyton Hart",       slackId: "U03QSALJWJZ" },
  { name: "Richard Roth",      slackId: "U8D14HNLU" },
];

async function init() {
  for (let attempt = 1; attempt <= 20; attempt++) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS kiosk_visits (
          id         SERIAL PRIMARY KEY,
          first_name TEXT NOT NULL,
          last_name  TEXT NOT NULL,
          host       TEXT NOT NULL,
          planned    BOOLEAN NOT NULL,
          reason     TEXT NOT NULL,
          ts         TIMESTAMPTZ NOT NULL
        )
      `);
      await pool.query(`
        CREATE TABLE IF NOT EXISTS kiosk_admins (
          email     TEXT PRIMARY KEY,
          name      TEXT NOT NULL,
          pass_hash TEXT NOT NULL,
          salt      TEXT NOT NULL
        )
      `);
      await pool.query(`
        CREATE TABLE IF NOT EXISTS kiosk_employees (
          id       SERIAL PRIMARY KEY,
          name     TEXT NOT NULL,
          slack_id TEXT
        )
      `);

      const admins = await pool.query("SELECT COUNT(*) AS c FROM kiosk_admins");
      if (Number(admins.rows[0].c) === 0) {
        for (const a of SEED_ADMINS) {
          const salt = crypto.randomBytes(16).toString("hex");
          await pool.query(
            "INSERT INTO kiosk_admins (email, name, pass_hash, salt) VALUES ($1, $2, $3, $4)",
            [a.email.toLowerCase(), a.name, hashPassword(a.password, salt), salt]
          );
        }
        console.log("Seeded " + SEED_ADMINS.length + " admin accounts");
      }

      const employees = await pool.query("SELECT COUNT(*) AS c FROM kiosk_employees");
      if (Number(employees.rows[0].c) === 0) {
        for (const e of SEED_EMPLOYEES) {
          await pool.query("INSERT INTO kiosk_employees (name, slack_id) VALUES ($1, $2)", [
            e.name,
            e.slackId || null,
          ]);
        }
        console.log("Seeded " + SEED_EMPLOYEES.length + " employees");
      }

      console.log("Database ready");
      return;
    } catch (e) {
      console.log("Waiting for database... (" + attempt + "/20): " + e.message);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
  throw new Error("Could not reach Postgres. Check the connection details in .env");
}

/* ---------- sessions (in memory; sign in again after a server restart) ---------- */
const SESSION_HOURS = 12;
const sessions = new Map();

function createSession(email, name) {
  const token = crypto.randomBytes(24).toString("hex");
  sessions.set(token, { email, name, created: Date.now() });
  return token;
}
function getSession(req) {
  const token = req.get("x-admin-token") || "";
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() - s.created > SESSION_HOURS * 3600 * 1000) {
    sessions.delete(token);
    return null;
  }
  return s;
}

/* ---------- public routes ---------- */
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, db: true });
  } catch (e) {
    res.status(500).json({ ok: true, db: false });
  }
});

app.get("/api/employees", async (req, res) => {
  try {
    const r = await pool.query("SELECT id, name, slack_id FROM kiosk_employees ORDER BY name");
    res.json(r.rows.map((e) => ({ id: e.id, name: e.name, slackId: e.slack_id })));
  } catch (e) {
    console.error("employees query failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/checkin", async (req, res) => {
  try {
    const b = req.body || {};
    const first = String(b.first || "").trim().slice(0, 80);
    const last = String(b.last || "").trim().slice(0, 80);
    const host = String(b.host || "").trim().slice(0, 120);
    const reason = String(b.reason || "").trim().slice(0, 200);
    const planned = Boolean(b.planned);

    if (!first || !last || !host || !reason) {
      return res.status(400).json({ error: "missing fields" });
    }
    await pool.query(
      "INSERT INTO kiosk_visits (first_name, last_name, host, planned, reason, ts) VALUES ($1, $2, $3, $4, $5, $6)",
      [first, last, host, planned, reason, new Date().toISOString()]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error("checkin failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const email = String((req.body || {}).email || "").trim().toLowerCase();
    const password = String((req.body || {}).password || "");
    const r = await pool.query("SELECT email, name, pass_hash, salt FROM kiosk_admins WHERE email = $1", [email]);
    const admin = r.rows[0];
    if (!admin || !verifyPassword(password, admin.salt, admin.pass_hash)) {
      return res.status(401).json({ error: "bad credentials" });
    }
    res.json({ token: createSession(admin.email, admin.name), name: admin.name });
  } catch (e) {
    console.error("login failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/logout", (req, res) => {
  sessions.delete(req.get("x-admin-token") || "");
  res.json({ ok: true });
});

/* ---------- admin routes (require a signed-in session) ---------- */
app.get("/api/visits", async (req, res) => {
  try {
    if (!getSession(req)) return res.status(401).json({ error: "unauthorized" });

    const from = req.query.from ? new Date(req.query.from) : new Date(0);
    const to = req.query.to ? new Date(req.query.to) : new Date();
    if (isNaN(from) || isNaN(to)) return res.status(400).json({ error: "bad date range" });

    const r = await pool.query(
      "SELECT first_name, last_name, host, planned, reason, ts FROM kiosk_visits WHERE ts BETWEEN $1 AND $2 ORDER BY ts DESC",
      [from.toISOString(), to.toISOString()]
    );
    res.json(r.rows);
  } catch (e) {
    console.error("visits query failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/change-password", async (req, res) => {
  try {
    const session = getSession(req);
    if (!session) return res.status(401).json({ error: "unauthorized" });

    const current = String((req.body || {}).current || "");
    const next = String((req.body || {}).next || "");
    if (next.length < 8) return res.status(400).json({ error: "new password too short" });

    const r = await pool.query("SELECT pass_hash, salt FROM kiosk_admins WHERE email = $1", [session.email]);
    const admin = r.rows[0];
    if (!admin || !verifyPassword(current, admin.salt, admin.pass_hash)) {
      return res.status(403).json({ error: "wrong current password" });
    }
    const salt = crypto.randomBytes(16).toString("hex");
    await pool.query("UPDATE kiosk_admins SET pass_hash = $1, salt = $2 WHERE email = $3", [
      hashPassword(next, salt), salt, session.email,
    ]);
    res.json({ ok: true });
  } catch (e) {
    console.error("change-password failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/employees", async (req, res) => {
  try {
    if (!getSession(req)) return res.status(401).json({ error: "unauthorized" });

    const name = String((req.body || {}).name || "").trim().slice(0, 120);
    const slackId = String((req.body || {}).slackId || "").trim().slice(0, 40);
    if (!name) return res.status(400).json({ error: "name required" });

    const exists = await pool.query("SELECT id FROM kiosk_employees WHERE lower(name) = lower($1)", [name]);
    if (exists.rows.length > 0) return res.status(409).json({ error: "duplicate name" });

    await pool.query("INSERT INTO kiosk_employees (name, slack_id) VALUES ($1, $2)", [name, slackId || null]);
    res.json({ ok: true });
  } catch (e) {
    console.error("add employee failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.delete("/api/employees/:id", async (req, res) => {
  try {
    if (!getSession(req)) return res.status(401).json({ error: "unauthorized" });
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) return res.status(400).json({ error: "bad id" });
    await pool.query("DELETE FROM kiosk_employees WHERE id = $1", [id]);
    res.json({ ok: true });
  } catch (e) {
    console.error("remove employee failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.get("/api/admins", async (req, res) => {
  try {
    if (!getSession(req)) return res.status(401).json({ error: "unauthorized" });
    const r = await pool.query("SELECT email, name FROM kiosk_admins ORDER BY name");
    res.json(r.rows);
  } catch (e) {
    console.error("admins query failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.post("/api/admins", async (req, res) => {
  try {
    if (!getSession(req)) return res.status(401).json({ error: "unauthorized" });

    const email = String((req.body || {}).email || "").trim().toLowerCase().slice(0, 120);
    const name = String((req.body || {}).name || "").trim().slice(0, 120);
    const password = String((req.body || {}).password || "");
    if (!email || email.indexOf("@") === -1 || !name) return res.status(400).json({ error: "name and email required" });
    if (password.length < 8) return res.status(400).json({ error: "password too short" });

    const exists = await pool.query("SELECT email FROM kiosk_admins WHERE email = $1", [email]);
    if (exists.rows.length > 0) return res.status(409).json({ error: "duplicate email" });

    const salt = crypto.randomBytes(16).toString("hex");
    await pool.query(
      "INSERT INTO kiosk_admins (email, name, pass_hash, salt) VALUES ($1, $2, $3, $4)",
      [email, name, hashPassword(password, salt), salt]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error("add admin failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

app.delete("/api/admins/:email", async (req, res) => {
  try {
    const session = getSession(req);
    if (!session) return res.status(401).json({ error: "unauthorized" });

    const email = String(req.params.email || "").trim().toLowerCase();
    if (email === session.email) return res.status(400).json({ error: "cannot remove yourself" });

    await pool.query("DELETE FROM kiosk_admins WHERE email = $1", [email]);
    for (const [t, s] of sessions) {
      if (s.email === email) sessions.delete(t);
    }
    res.json({ ok: true });
  } catch (e) {
    console.error("remove admin failed:", e.message);
    res.status(500).json({ error: "server error" });
  }
});

const PORT = process.env.PORT || 3000;
init().then(() => {
  app.listen(PORT, () => console.log("Visitor kiosk running on port " + PORT));
});
